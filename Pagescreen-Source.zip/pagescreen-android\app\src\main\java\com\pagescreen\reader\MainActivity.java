package com.pagescreen.reader;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    private ValueCallback<Uri[]> fileCallback;
    private ActivityResultLauncher<Intent> pdfPicker;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView.setWebContentsDebuggingEnabled(false);
        WebView reader = new WebView(this);
        setContentView(reader);

        pdfPicker = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (fileCallback == null) return;
            Uri[] files = result.getResultCode() == RESULT_OK && result.getData() != null && result.getData().getData() != null
                ? new Uri[]{result.getData().getData()} : null;
            fileCallback.onReceiveValue(files);
            fileCallback = null;
        });

        WebViewAssetLoader assets = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        reader.setWebViewClient(new WebViewClientCompat() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, android.webkit.WebResourceRequest request) {
                return assets.shouldInterceptRequest(request.getUrl());
            }
        });
        reader.getSettings().setJavaScriptEnabled(true);
        reader.getSettings().setDomStorageEnabled(true);
        reader.getSettings().setAllowFileAccess(false);
        reader.getSettings().setBuiltInZoomControls(false);
        reader.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent pickPdf = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pickPdf.addCategory(Intent.CATEGORY_OPENABLE);
                pickPdf.setType("application/pdf");
                pdfPicker.launch(pickPdf);
                return true;
            }
        });
        reader.loadUrl("https://appassets.androidplatform.net/assets/pagescreen.html");
    }

    @Override public void onBackPressed() {
        WebView web = (WebView) ((android.view.ViewGroup) findViewById(android.R.id.content)).getChildAt(0);
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
