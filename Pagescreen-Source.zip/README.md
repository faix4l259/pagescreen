# Pagescreen

A color-safe, night-aware PDF reader. Open `pagescreen.html` in a browser to use the reader.

## Android project

The `pagescreen-android` folder contains the Android WebView wrapper. It loads the same reader from its bundled assets and supports selecting PDFs from the device.

## Included

- Local PDF library with resume and remove controls
- Color palette, custom text/page colors, search, page jump, zoom, and reading-flow controls
- Color-safe rendering designed to leave diagram colors unchanged
